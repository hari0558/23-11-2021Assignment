package com.yash.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServletControlClass
 */
@WebServlet(name = "LoginServletControl", urlPatterns = { "/loginservletcontrol" })
public class LoginServletControlClass extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServletControlClass() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    int attempt=0;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		
		HttpSession session =request.getSession(true);
		if(username.equals("hari123") && password.equals("hari123")) {
			session.setAttribute("attempt", ""+attempt);
			RequestDispatcher dispatcher=request.getRequestDispatcher("welcomeservlet");
			dispatcher.forward(request, response);
		}
		else {
			attempt++;
			RequestDispatcher dispatcher=request.getRequestDispatcher("Login.html");
			dispatcher.include(request, response);
			out.print("<script>alert('invalid username/password')</script>");
		}
		if(attempt>3) {
			out.print("<script>alert('Account is locked')</script>");
		}
	}

}
